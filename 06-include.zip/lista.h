#include<stdio.h>
#pragma once

struct ListNode {
	int val;
	struct ListNode *next;
};

struct List {
	struct ListNode *head;
};

void init(struct List *lista) {
	lista -> head = NULL;
}

void print(struct List *lista) {
	struct ListNode *ptr = lista -> head;
	while(ptr != NULL) {
		printf("%d%c", ptr -> val, " \n"[ptr -> next == NULL]);
		ptr = ptr -> next;
	}
}
