#include "lista.h"
#include "solver.h"
#include<stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	struct List lista;
	init(&lista);
	for(int i = 1; i <= n; i++) {
		int x;
		scanf("%d", &x);
		insert(&lista, i, x);
	}
	print(&lista);
	return 0;
}
