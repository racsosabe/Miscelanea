import requests, hashlib
from random import randint
from time import time

def get_group_status(api_key, api_secret, contest_id, group_code):
    rand = randint(0, 100000)
    rand = str(rand).zfill(6)
    current_time = str(int(time()))
    api_sig = rand + '/contest.status?apiKey=' + api_key + '&asManager=true' + '&contestId=' + contest_id + '&groupCode=' + group_code + '&time=' + current_time + '#' + api_secret
    hash = hashlib.sha512(api_sig.encode()).hexdigest()
    data = requests.get(f'https://codeforces.com/api/contest.status?groupCode={group_code}&asManager=true&contestId={contest_id}&apiKey={api_key}&time={current_time}&apiSig={rand+hash}').json()
    return data

def get_group_standings(api_key, api_secret, contest_id, group_code):
    rand = randint(0, 100000)
    rand = str(rand).zfill(6)
    current_time = str(int(time()))
    api_sig = rand + '/contest.standings?apiKey=' + api_key + '&asManager=true' + '&contestId=' + contest_id + '&groupCode=' + group_code + '&time=' + current_time + '#' + api_secret
    hash = hashlib.sha512(api_sig.encode()).hexdigest()
    data = requests.get(f'https://codeforces.com/api/contest.standings?groupCode={group_code}&asManager=true&contestId={contest_id}&apiKey={api_key}&time={current_time}&apiSig={rand+hash}').json()
    return data

def get_public_status_as_manager(api_key, api_secret, contest_id):
    rand = randint(0, 100000)
    rand = str(rand).zfill(6)
    current_time = str(int(time()))
    api_sig = rand + '/contest.status?apiKey=' + api_key + '&contestId=' + contest_id + '&asManager=true' + '&time=' + current_time + '#' + api_secret
    hash = hashlib.sha512(api_sig.encode()).hexdigest()
    data = requests.get(f'https://codeforces.com/api/contest.status?asManager=true&contestId={contest_id}&apiKey={api_key}&time={current_time}&apiSig={rand+hash}').json()
    return data

def get_public_standings_as_manager(api_key, api_secret, contest_id):
    rand = randint(0, 100000)
    rand = str(rand).zfill(6)
    current_time = str(int(time()))
    api_sig = rand + '/contest.standings?apiKey=' + api_key + '&contestId=' + contest_id + '&asManager=true' + '&time=' + current_time + '#' + api_secret
    hash = hashlib.sha512(api_sig.encode()).hexdigest()
    data = requests.get(f'https://codeforces.com/api/contest.standings?asManager=true&contestId={contest_id}&apiKey={api_key}&time={current_time}&apiSig={rand+hash}').json()
    return data

def get_public_status(contest_id):
    rand = randint(0, 100000)
    rand = str(rand).zfill(6)
    current_time = str(int(time()))
    api_sig = rand + '/contest.status?contestId=' + contest_id + '&asManager=false' + '&time=' + current_time
    hash = hashlib.sha512(api_sig.encode()).hexdigest()
    data = requests.get(f'https://codeforces.com/api/contest.status?asManager=false&contestId={contest_id}&time={current_time}&apiSig={rand+hash}').json()
    return data

def get_public_standings(contest_id):
    rand = randint(0, 100000)
    rand = str(rand).zfill(6)
    current_time = str(int(time()))
    api_sig = rand + '/contest.standings?contestId=' + contest_id + '&asManager=false' + '&time=' + current_time
    hash = hashlib.sha512(api_sig.encode()).hexdigest()
    data = requests.get(f'https://codeforces.com/api/contest.standings?asManager=false&contestId={contest_id}&time={current_time}&apiSig={rand+hash}').json()
    return data