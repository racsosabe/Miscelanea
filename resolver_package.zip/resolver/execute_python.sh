#!/bin/bash

python3 replace_second_place.py
