
FILENAME = 'feed-awards.ndjson'
OUTPUT_FILE = 'feed-awards_corrected.ndjson'
SECOND_PLACE = '2\\u00ba puesto'
CORRECT_SECOND_PLACE = '2do puesto'

out = open(OUTPUT_FILE, 'w')

print("Fixing awards")

with open(FILENAME, 'r', encoding = 'utf-8') as file:
    for line in file:
        out.write(line.replace(SECOND_PLACE, CORRECT_SECOND_PLACE))

out.close()

print("Successfully fixed")
