#!/bin/bash
# Purpose: to apply awards to an event feed

if [ -z "$1" ]; then
    echo "Must give event feed file"
    exit 1
fi

rm -f feed-awards.ndjson && \
./awards.sh "$1" --medals 1 1 1 --rank 3 --firstPlaceCitation "Campeon de la Competencia" && \
python3 replace_second_place.py "$@" && \
rm -f feed-awards.ndjson && \
cp feed-awards_corrected.ndjson feed-awards.ndjson && \
./resolver.sh feed-awards.ndjson --singleStep 999
