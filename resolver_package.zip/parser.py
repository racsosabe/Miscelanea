import sys
import tomllib
from json import dumps
from time import strftime, gmtime
from datetime import datetime, timedelta, UTC
from cf_query import *

CONFIG_FILE = 'config.toml'
OUTPUT_FILE = 'feed.json'
AUTH_FIELD = 'auth'
CONTEST_FIELD = 'contest'
UTC_DIFF = 0
API_KEY_FIELD = 'api_key'
API_SECRET_FIELD = 'api_secret'
GROUP_CODE_FIELD = 'group_code'
CONTEST_ID_FIELD = 'contest_id'
FROZEN_TIME_FIELD = 'frozen_time'
PENALTY_TIME_FIELD = 'penalty_time'
UTC_DIFF_FIELD = 'utc_diff'

def read_first_line(filename):
    with open(filename, 'r') as file:
        line = file.readlines()[0].strip()
        return line if len(line) > 0 else None
    return None

def get_field(data, field):
    return data[field] if field in data else None

def parse_toml(filename):
    with open(filename, "rb") as f:
        data = tomllib.load(f)
        return data
    return None

def parse_config():
    data = parse_toml(CONFIG_FILE)
    if data is None:
        return None, None, None, None, None, None, None
    
    auth_data = get_field(data, AUTH_FIELD)
    if auth_data is None:
        return None, None, None, None, None, None, None
    contest_data = get_field(data, CONTEST_FIELD)
    if contest_data is None:
        return None, None, None, None, None, None, None
    api_key = get_field(auth_data, API_KEY_FIELD)
    api_secret = get_field(auth_data, API_SECRET_FIELD)
    group_code = get_field(contest_data, GROUP_CODE_FIELD)
    contest_id = get_field(contest_data, CONTEST_ID_FIELD)
    frozen_time = get_field(contest_data, FROZEN_TIME_FIELD)
    penalty_time = get_field(contest_data, PENALTY_TIME_FIELD)
    utc_diff = get_field(contest_data, UTC_DIFF_FIELD)
    if utc_diff is None:
        utc_diff = 0
    return api_key, api_secret, group_code, contest_id, frozen_time, penalty_time, utc_diff

def get_contest_info(contest, frozen, penalty):
    data = dict()
    data['id'] = contest['id']
    data['name'] = contest['name']
    data['start_time'] = datetime.fromtimestamp(contest['startTimeSeconds'] + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    data['duration'] = strftime('%H:%M:%S', gmtime(contest['durationSeconds']))
    data['scoreboard_type'] = 'pass-fail'
    data['scoreboard_freeze_duration'] = frozen
    data['penalty_time'] = penalty
    return data

def parse_team_id(party):
    if 'teamName' in party:
        return party['teamName']
    return ','.join(x['handle'] for x in party['members'])

def get_participants_info(rows):
    response = []
    for row in rows:
        if row['party']['participantType'] != 'CONTESTANT' or row['party']['ghost']: continue
        team_id = parse_team_id(row['party'])
        data = dict()
        data['id'] = team_id
        data['name'] = team_id
        data['label'] = team_id
        response.append(data)
    return response

def get_problems_info(problems):
    response = []
    at = 1
    for problem in problems:
        data = dict()
        data['id'] = problem['name']
        data['label'] = problem['index']
        data['name'] = problem['name']
        data['ordinal'] = at
        data['time_limit'] = 1
        data['test_data_count'] = 10
        at += 1
        response.append(data)
    return response

def get_judgement_type_id(veredict):
    if veredict == 'OK':
        return 'AC'
    if veredict == 'TIME_LIMIT_EXCEEDED':
        return 'TLE'
    if veredict == 'MEMORY_LIMIT_EXCEEDED':
        return 'MLE'
    if veredict == 'IDLENESS_LIMIT_EXCEEDED':
        return 'ILE'
    if veredict == 'RUNTIME_ERROR':
        return 'RTE'
    if veredict == 'COMPILATION_ERROR':
        return 'CE'
    if veredict == 'PRESENTATION_ERROR':
        return 'PE'
    return 'WA'

def get_judgement_type_info():
    response = []
    ids = ['AC', 'TLE', 'MLE', 'ILE', 'RTE', 'CE', 'PE', 'WA']
    names = ['Accepted', 'Time Limit Exceeded', 'Memory Limit Exceeded', 'Idleness Limit Exceeded', 'Runtime Error', 'Compilation Error', 'Presentation Error', 'Wrong Answer']
    for i in range(len(ids)):
        data = dict()
        data['id'] = ids[i]
        data['name'] = names[i]
        data['penalty'] = i > 0
        data['solved'] = i == 0
        response.append(data)
    return response

def get_language_info():
    response = []
    ids = ['c', 'cpp', 'java', 'python', 'kotlin']
    names = ['C', 'C++', 'Java', 'Python', 'Kotlin']
    extensions = [['c'], ['cpp', 'cc', 'cxx', 'c++', 'c'], ['java'], ['py'], ['kt']]
    compilers = [{'command' : 'gcc'}, {'command' : 'g++'}, {'command' : 'javac'}, {'command' : 'python'}, {'command' : 'kotlinc'}]
    runners = [None, None, {'command' : 'java'}, {'command' : 'python'}, {'command' : 'java -jar'}]
    for i in range(len(ids)):
        data = dict()
        data['id'] = ids[i]
        data['name'] = names[i]
        data['entry_point_required'] = False
        data['extensions'] = extensions[i]
        data['compiler'] = compilers[i]
        if runners[i]: data['runner'] = runners[i]
        response.append(data)
    return response

def get_submission_events(status):
    submissions = []
    judgements = []
    runs = []
    status.sort(key = lambda submission : submission['creationTimeSeconds'])
    id = 1
    run_id = 1
    for submission in status:
        if 'verdict' not in submission: continue
        if submission['relativeTimeSeconds'] > 60 * 60 * 5: continue
        #print(submission)
        if submission['programmingLanguage'].find('Kotlin') != -1:
            language_id = 'kotlin'
        elif submission['programmingLanguage'].find('Py') != -1:
            language_id = 'python'
        elif submission['programmingLanguage'].find('Java') != -1:
            language_id = 'java'
        elif submission['programmingLanguage'].find('GCC') != -1 or submission['programmingLanguage'].find('GNU C') != -1:
            language_id = 'c'
        elif submission['programmingLanguage'].find('C++') != -1 or submission['programmingLanguage'].find('G++') != -1:
            language_id = 'cpp'
        else:
            #print("Unknown language", submission['programmingLanguage'])
            language_id = 'cpp'
        if submission['author']['participantType'] != 'CONTESTANT' or submission['author']['ghost']: continue
        team_id = parse_team_id(submission['author'])
        time = datetime.fromtimestamp(submission['creationTimeSeconds'] + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
        contest_time = timedelta(seconds = submission['relativeTimeSeconds'])
        problem_id = submission['problem']['name']
        judgement_data = dict()
        judgement_data['id'] = str(id)
        judgement_data['submission_id'] = str(id)
        judgement_data['judgement_type_id'] = get_judgement_type_id(submission['verdict'])
        judgement_data['start_time'] = str(time)
        judgement_data['end_time'] = str(time)
        judgement_data['start_contest_time'] = str(contest_time)
        judgement_data['end_contest_time'] = str(contest_time)
        submission_data = dict()
        submission_data['team_id'] = team_id
        submission_data['time'] = str(time)
        submission_data['contest_time'] = str(contest_time)
        submission_data['problem_id'] = problem_id
        submission_data['id'] = str(id)
        submission_data['language_id'] = language_id
        run_list = []
        for j in range(1, 10):
            run_data = dict()
            run_data['id'] = run_id
            run_data['judgement_id'] = str(id)
            run_data['ordinal'] = j
            run_data['judgement_type_id'] = 'AC'
            run_data['time'] = str(time)
            run_data['contest_time'] = str(contest_time + timedelta(seconds = j - 1))
            run_data['run_time'] = 1
            run_list.append(run_data)
            run_id += 1
        run_data = dict()
        run_data['id'] = run_id
        run_data['judgement_id'] = str(id)
        run_data['ordinal'] = 10
        run_data['judgement_type_id'] = get_judgement_type_id(submission['verdict'])
        run_data['time'] = str(time)
        run_data['contest_time'] = str(contest_time + timedelta(seconds = 9))
        run_data['run_time'] = 1
        run_list.append(run_data)
        run_id += 1
        submissions.append(submission_data)
        judgements.append(judgement_data)
        runs.append(run_list)
        id += 1
    return (submissions, judgements, runs)

def get_map(type, data, id = None):
    response = dict()
    response['type'] = type
    response['data'] = data
    if id is None: return response
    response['id'] = id
    return response

def get_starting_state_info(contest):
    data = dict()
    data['started'] = datetime.fromtimestamp(contest['startTimeSeconds'] + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    return data

def get_freezing_state_info(contest):
    data = dict()
    data['started'] = datetime.fromtimestamp(contest['startTimeSeconds'] + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    data['frozen'] = datetime.fromtimestamp(contest['startTimeSeconds'] + contest['durationSeconds'] - 60 * 60 + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    return data

def get_ending_state_info(contest):
    data = dict()
    data['started'] = datetime.fromtimestamp(contest['startTimeSeconds'] + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    data['frozen'] = datetime.fromtimestamp(contest['startTimeSeconds'] + contest['durationSeconds'] - 60 * 60 + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    data['ended'] = datetime.fromtimestamp(contest['startTimeSeconds'] + contest['durationSeconds'] + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    data['finalized'] = datetime.fromtimestamp(contest['startTimeSeconds'] + contest['durationSeconds'] + 1 + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    data['end_of_updates'] = datetime.fromtimestamp(contest['startTimeSeconds'] + contest['durationSeconds'] + 20 + 60 * 60 * UTC_DIFF, UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    return data

def main():
    global UTC_DIFF
    API_KEY, API_SECRET, GROUP_CODE, CONTEST_ID, FROZEN_TIME, PENALTY, UTC_DIFF = parse_config()

    if CONTEST_ID is None:
        print("Error, contest id not found")
        sys.exit(0)
    
    event_id = 1
    if GROUP_CODE is not None:
        standings = get_group_standings(API_KEY, API_SECRET, CONTEST_ID, GROUP_CODE)['result']
        status = get_group_status(API_KEY, API_SECRET, CONTEST_ID, GROUP_CODE)['result']
    else:
        standings = get_public_standings(CONTEST_ID)['result']
        status = get_public_status(CONTEST_ID)['result']
    with open(OUTPUT_FILE, 'w') as outf:
        contest_info = get_contest_info(standings['contest'], FROZEN_TIME, PENALTY)
        outf.write(dumps(get_map('contest', contest_info)))#.replace('\'', '\"'))
        outf.write("\n")
        language_info = get_language_info()
        outf.write(dumps(get_map('languages', language_info)))#.replace('\'', '\"'))
        outf.write("\n")
        judgement_type_info = get_judgement_type_info()
        outf.write(dumps(get_map('judgement-types', judgement_type_info)))#.replace('\'', '\"'))
        outf.write("\n")
        problems_info = get_problems_info(standings['problems'])
        outf.write(dumps(get_map('problems', problems_info)))#.replace('\'', '\"'))
        outf.write("\n")
        participants_info = get_participants_info(standings['rows'])
        outf.write(dumps(get_map('teams', participants_info)))#.replace('\'', '\"'))
        outf.write("\n")
        starting_state_info = get_starting_state_info(standings['contest'])
        outf.write(dumps(get_map('state', starting_state_info)))#.replace('\'', '\"'))
        outf.write("\n")
        submissions, judgements, runs = get_submission_events(status)
        frozen = False
        for i in range(len(submissions)):
            if submissions[i]['contest_time'] > '4:00:00' and not frozen:
                frozen = True
                freezing_state_info = get_freezing_state_info(standings['contest'])
                outf.write(dumps(get_map('state', freezing_state_info)))#.replace('\'', '\"'))
                outf.write("\n")
            outf.write(dumps(get_map('submissions', submissions[i], event_id)))#.replace('\'', '\"'))
            outf.write("\n")
            event_id += 1
            judgement_type_id = judgements[i]['judgement_type_id']
            judgements[i]['judgement_type_id'] = None
            judgements[i]['end_time'] = None
            judgements[i]['end_contest_time'] = None
            outf.write(dumps(get_map('judgements', judgements[i], event_id)))#.replace('\'', '\"'))
            outf.write("\n")
            event_id += 1
            last_end_contest_time = ''
            last_end_time = ''
            for run in runs[i]:
                last_end_contest_time = run['contest_time']
                last_end_time = run['time']
                outf.write(dumps(get_map('runs', run, event_id)))#.replace('\'', '\"'))
                outf.write("\n")
                event_id += 1
            judgements[i]['judgement_type_id'] = judgement_type_id
            judgements[i]['end_time'] = last_end_time
            judgements[i]['end_contest_time'] = last_end_contest_time
            outf.write(dumps(get_map('judgements', judgements[i], event_id)))#.replace('\'', '\"'))
            outf.write("\n")
            event_id += 1
        ending_state_info = get_ending_state_info(standings['contest'])
        outf.write(dumps(get_map('state', ending_state_info)))#.replace('\'', '\"'))
        outf.write("\n")


if __name__ == '__main__':
    main()
