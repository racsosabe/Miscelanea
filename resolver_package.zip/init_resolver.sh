#!/bin/bash
# Purpose: to apply awards to an event feed

python3 parser.py && \
cp -f feed.json resolver/feed.json && \
cd resolver && \
./generate_awards.sh feed.json && \
cd ..
